package ir.hosseinrasti.app.jobjo.ui.activites.modify.profile;

/**
 * Created by Hossein on 7/18/2018.
 */

public class ModifyProfilePresenter {

}
