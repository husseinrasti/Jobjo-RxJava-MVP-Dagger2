package ir.hosseinrasti.app.jobjo.utils.enums;

/**
 * Created by Hossein on 7/13/2018.
 */

public enum Action {
    CLICK,
    APPLY,
    DELETE,
    SHARE,
    COMMENT,
    MODIFY
}
